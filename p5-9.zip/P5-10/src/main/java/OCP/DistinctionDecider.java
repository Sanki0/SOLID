package OCP;
import java.util.Arrays;
import java.util.List;

interface DistinctionDecider {
    void evaluateDistinction(Estudiante a);
}